#include <iostream>
#include <cstring>
#include "clsAlumno.h"

using namespace std;

/**
Crear un programa con un men� con las siguientes opciones:
1-Agregar un registro al archivo.
2-Listar los registros del archivo.
EXTRA:
Hacer una opci�n que reciba una posici�n y liste el registro de esa posici�n (el primer registro de mi archivo ocupa la posici�n 0).
*/

int main()
{
//    Alumno obj[2];
    Alumno obj;
//    obj.Cargar();
    FILE *pArchivo;
    ///ABRO EL ARCHIVO EN EL MODO QUE YO NECESITO. CREA UN VINCULO CON EL ARCHIVO EN EL PUNTERO FILE.
    pArchivo = fopen("alumnos.dat", "rb");
    /**
    MODOS DE APERTURA:
    r (read): ABRE EL ARCHIVO EN MODO LECTURA. SI NO EXISTE EL ARCHIVO, NO LO CREA.
    a (append): ABRE EL ARCHIVO EN MODO ESCRITURA. SI NO EXISTE EL ARCHIVO, LO CREA. SIEMPRE ESCRIBE AL FINAL DEL ARCHIVO.
    w (write): ABRE EL ARCHIVO EN MODO ESCRITURA. SIEMPRE CREA UN ARCHIVO VACIO.
    b (binary): INDICA QUE TRABAJAMOS CON ARCHIVOS BINARIOS.
    */
    if(pArchivo == nullptr){
        cout<<"ERROR DE APERTURA DEL ARCHIVO"<<endl;
        return -1;
    }
//    fwrite(&obj, sizeof obj, 1, pArchivo);
    /**
    Primer argumento: direcci�n de memoria donde est� la informaci�n que quiero copiar a mi archivo.
    Segundo argumento: cantidad de bytes que quiero copiar a mi archivo (peso de un objeto/tipo de datos).
    Tercer argumento: cantidad de registros que quiero copiar a mi archivo.
    Cuarto argumento: v�nculo con mi archivo (puntero FILE sobre el que hice la apertura).
    */
///    fread(&obj, sizeof (Alumno), 1, pArchivo)<<endl;
    /**
    Primer argumento: direcci�n de memoria donde quiero copiar la informaci�n leo de mi archivo.
    Segundo argumento: cantidad de bytes que quiero leer de mi archivo (peso de un objeto/tipo de datos).
    Tercer argumento: cantidad de registros que quiero leer de mi archivo.
    Cuarto argumento: v�nculo con mi archivo (puntero FILE sobre el que hice la apertura).
    */
    while(fread(&obj, sizeof obj, 1, pArchivo) == 1){
        cout<<"========================"<<endl;
        obj.Mostrar();
    }
    fclose(pArchivo);
    return 0;
}
